/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "C:/Users/18298/Desktop/clases itla 2023/sistemas digitales personal/clock_y_multiplexor_jorge/modulofrecuencia_display.v";
static unsigned int ng1[] = {1U, 0U};
static unsigned int ng2[] = {2272727U, 0U};
static int ng3[] = {1, 0};
static unsigned int ng4[] = {0U, 0U};
static unsigned int ng5[] = {25000000U, 0U};
static unsigned int ng6[] = {12500000U, 0U};
static unsigned int ng7[] = {8333333U, 0U};
static unsigned int ng8[] = {6250000U, 0U};
static unsigned int ng9[] = {5000000U, 0U};
static unsigned int ng10[] = {4166666U, 0U};
static unsigned int ng11[] = {3571428U, 0U};
static int ng12[] = {2, 0};



static void Always_51_0(char *t0)
{
    char t8[8];
    char t10[8];
    char t20[8];
    char t21[8];
    char *t1;
    char *t2;
    char *t3;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    char *t9;
    char *t11;
    char *t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    unsigned int t16;
    unsigned int t17;
    char *t18;
    char *t19;
    unsigned int t22;
    unsigned int t23;
    unsigned int t24;
    char *t25;
    unsigned int t26;
    unsigned int t27;
    unsigned int t28;
    unsigned int t29;
    char *t30;
    char *t31;

LAB0:    t1 = (t0 + 5856U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(51, ng0);
    t2 = (t0 + 6176);
    *((int *)t2) = 1;
    t3 = (t0 + 5888);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(52, ng0);

LAB5:    xsi_set_current_line(53, ng0);
    t4 = (t0 + 3816);
    t5 = (t4 + 56U);
    t6 = *((char **)t5);
    t7 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t6, 27, t7, 27);
    t9 = (t0 + 3816);
    xsi_vlogvar_wait_assign_value(t9, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(54, ng0);
    t2 = (t0 + 3976);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t4, 27, t5, 27);
    t6 = (t0 + 3976);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(55, ng0);
    t2 = (t0 + 4136);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t4, 27, t5, 27);
    t6 = (t0 + 4136);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(56, ng0);
    t2 = (t0 + 4136);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t4, 27, t5, 27);
    t6 = (t0 + 4136);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(57, ng0);
    t2 = (t0 + 4296);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t4, 27, t5, 27);
    t6 = (t0 + 4296);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(58, ng0);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t4, 27, t5, 27);
    t6 = (t0 + 4456);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(59, ng0);
    t2 = (t0 + 4616);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t4, 27, t5, 27);
    t6 = (t0 + 4616);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(60, ng0);
    t2 = (t0 + 4776);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t4, 27, t5, 27);
    t6 = (t0 + 4776);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(61, ng0);
    t2 = (t0 + 4936);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng1)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_add(t8, 27, t4, 27, t5, 27);
    t6 = (t0 + 4936);
    xsi_vlogvar_wait_assign_value(t6, t8, 0, 0, 27, 0LL);
    xsi_set_current_line(63, ng0);
    t2 = (t0 + 3816);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 32, t5, 27, t6, 32);
    memset(t10, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB7;

LAB6:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB7;

LAB10:    if (*((unsigned int *)t4) < *((unsigned int *)t8))
        goto LAB9;

LAB8:    *((unsigned int *)t10) = 1;

LAB9:    t12 = (t10 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t10);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB11;

LAB12:
LAB13:    xsi_set_current_line(65, ng0);
    t2 = (t0 + 3976);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 32, t5, 27, t6, 32);
    memset(t10, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB15;

LAB14:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB15;

LAB18:    if (*((unsigned int *)t4) < *((unsigned int *)t8))
        goto LAB17;

LAB16:    *((unsigned int *)t10) = 1;

LAB17:    t12 = (t10 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t10);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB19;

LAB20:
LAB21:    xsi_set_current_line(67, ng0);
    t2 = (t0 + 4136);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng6)));
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 32, t5, 27, t6, 32);
    memset(t10, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB23;

LAB22:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB23;

LAB26:    if (*((unsigned int *)t4) < *((unsigned int *)t8))
        goto LAB25;

LAB24:    *((unsigned int *)t10) = 1;

LAB25:    t12 = (t10 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t10);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB27;

LAB28:
LAB29:    xsi_set_current_line(69, ng0);
    t2 = (t0 + 4296);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng7)));
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 32, t5, 27, t6, 32);
    memset(t10, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB31;

LAB30:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB31;

LAB34:    if (*((unsigned int *)t4) < *((unsigned int *)t8))
        goto LAB33;

LAB32:    *((unsigned int *)t10) = 1;

LAB33:    t12 = (t10 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t10);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB35;

LAB36:
LAB37:    xsi_set_current_line(71, ng0);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng8)));
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 32, t5, 27, t6, 32);
    memset(t10, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB39;

LAB38:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB39;

LAB42:    if (*((unsigned int *)t4) < *((unsigned int *)t8))
        goto LAB41;

LAB40:    *((unsigned int *)t10) = 1;

LAB41:    t12 = (t10 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t10);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB43;

LAB44:
LAB45:    xsi_set_current_line(73, ng0);
    t2 = (t0 + 4616);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng9)));
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 32, t5, 27, t6, 32);
    memset(t10, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB47;

LAB46:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB47;

LAB50:    if (*((unsigned int *)t4) < *((unsigned int *)t8))
        goto LAB49;

LAB48:    *((unsigned int *)t10) = 1;

LAB49:    t12 = (t10 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t10);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB51;

LAB52:
LAB53:    xsi_set_current_line(75, ng0);
    t2 = (t0 + 4776);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng10)));
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 32, t5, 27, t6, 32);
    memset(t10, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB55;

LAB54:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB55;

LAB58:    if (*((unsigned int *)t4) < *((unsigned int *)t8))
        goto LAB57;

LAB56:    *((unsigned int *)t10) = 1;

LAB57:    t12 = (t10 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t10);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB59;

LAB60:
LAB61:    xsi_set_current_line(77, ng0);
    t2 = (t0 + 4936);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng11)));
    t6 = ((char*)((ng3)));
    memset(t8, 0, 8);
    xsi_vlog_unsigned_minus(t8, 32, t5, 27, t6, 32);
    memset(t10, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB63;

LAB62:    t9 = (t8 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB63;

LAB66:    if (*((unsigned int *)t4) < *((unsigned int *)t8))
        goto LAB65;

LAB64:    *((unsigned int *)t10) = 1;

LAB65:    t12 = (t10 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t10);
    t16 = (t15 & t14);
    t17 = (t16 != 0);
    if (t17 > 0)
        goto LAB67;

LAB68:
LAB69:    xsi_set_current_line(80, ng0);
    t2 = (t0 + 3816);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng2)));
    t6 = ((char*)((ng12)));
    memset(t20, 0, 8);
    xsi_vlog_unsigned_divide(t20, 32, t5, 27, t6, 32);
    memset(t21, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB71;

LAB70:    t9 = (t20 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB71;

LAB74:    if (*((unsigned int *)t4) < *((unsigned int *)t20))
        goto LAB72;

LAB73:    memset(t10, 0, 8);
    t12 = (t21 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t21);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB75;

LAB76:    if (*((unsigned int *)t12) != 0)
        goto LAB77;

LAB78:    t19 = (t10 + 4);
    t22 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t19);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB79;

LAB80:    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t19);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB81;

LAB82:    if (*((unsigned int *)t19) > 0)
        goto LAB83;

LAB84:    if (*((unsigned int *)t10) > 0)
        goto LAB85;

LAB86:    memcpy(t8, t30, 8);

LAB87:    t31 = (t0 + 2536);
    xsi_vlogvar_wait_assign_value(t31, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(81, ng0);
    t2 = (t0 + 3976);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng5)));
    t6 = ((char*)((ng12)));
    memset(t20, 0, 8);
    xsi_vlog_unsigned_divide(t20, 32, t5, 27, t6, 32);
    memset(t21, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB89;

LAB88:    t9 = (t20 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB89;

LAB92:    if (*((unsigned int *)t4) < *((unsigned int *)t20))
        goto LAB90;

LAB91:    memset(t10, 0, 8);
    t12 = (t21 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t21);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB93;

LAB94:    if (*((unsigned int *)t12) != 0)
        goto LAB95;

LAB96:    t19 = (t10 + 4);
    t22 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t19);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB97;

LAB98:    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t19);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB99;

LAB100:    if (*((unsigned int *)t19) > 0)
        goto LAB101;

LAB102:    if (*((unsigned int *)t10) > 0)
        goto LAB103;

LAB104:    memcpy(t8, t30, 8);

LAB105:    t31 = (t0 + 2696);
    xsi_vlogvar_wait_assign_value(t31, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(82, ng0);
    t2 = (t0 + 4136);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng6)));
    t6 = ((char*)((ng12)));
    memset(t20, 0, 8);
    xsi_vlog_unsigned_divide(t20, 32, t5, 27, t6, 32);
    memset(t21, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB107;

LAB106:    t9 = (t20 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB107;

LAB110:    if (*((unsigned int *)t4) < *((unsigned int *)t20))
        goto LAB108;

LAB109:    memset(t10, 0, 8);
    t12 = (t21 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t21);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB111;

LAB112:    if (*((unsigned int *)t12) != 0)
        goto LAB113;

LAB114:    t19 = (t10 + 4);
    t22 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t19);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB115;

LAB116:    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t19);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB117;

LAB118:    if (*((unsigned int *)t19) > 0)
        goto LAB119;

LAB120:    if (*((unsigned int *)t10) > 0)
        goto LAB121;

LAB122:    memcpy(t8, t30, 8);

LAB123:    t31 = (t0 + 2856);
    xsi_vlogvar_wait_assign_value(t31, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(83, ng0);
    t2 = (t0 + 4296);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng7)));
    t6 = ((char*)((ng12)));
    memset(t20, 0, 8);
    xsi_vlog_unsigned_divide(t20, 32, t5, 27, t6, 32);
    memset(t21, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB125;

LAB124:    t9 = (t20 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB125;

LAB128:    if (*((unsigned int *)t4) < *((unsigned int *)t20))
        goto LAB126;

LAB127:    memset(t10, 0, 8);
    t12 = (t21 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t21);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB129;

LAB130:    if (*((unsigned int *)t12) != 0)
        goto LAB131;

LAB132:    t19 = (t10 + 4);
    t22 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t19);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB133;

LAB134:    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t19);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB135;

LAB136:    if (*((unsigned int *)t19) > 0)
        goto LAB137;

LAB138:    if (*((unsigned int *)t10) > 0)
        goto LAB139;

LAB140:    memcpy(t8, t30, 8);

LAB141:    t31 = (t0 + 3016);
    xsi_vlogvar_wait_assign_value(t31, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(84, ng0);
    t2 = (t0 + 4456);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng7)));
    t6 = ((char*)((ng12)));
    memset(t20, 0, 8);
    xsi_vlog_unsigned_divide(t20, 32, t5, 27, t6, 32);
    memset(t21, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB143;

LAB142:    t9 = (t20 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB143;

LAB146:    if (*((unsigned int *)t4) < *((unsigned int *)t20))
        goto LAB144;

LAB145:    memset(t10, 0, 8);
    t12 = (t21 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t21);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB147;

LAB148:    if (*((unsigned int *)t12) != 0)
        goto LAB149;

LAB150:    t19 = (t10 + 4);
    t22 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t19);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB151;

LAB152:    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t19);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB153;

LAB154:    if (*((unsigned int *)t19) > 0)
        goto LAB155;

LAB156:    if (*((unsigned int *)t10) > 0)
        goto LAB157;

LAB158:    memcpy(t8, t30, 8);

LAB159:    t31 = (t0 + 3176);
    xsi_vlogvar_wait_assign_value(t31, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(85, ng0);
    t2 = (t0 + 4616);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng9)));
    t6 = ((char*)((ng12)));
    memset(t20, 0, 8);
    xsi_vlog_unsigned_divide(t20, 32, t5, 27, t6, 32);
    memset(t21, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB161;

LAB160:    t9 = (t20 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB161;

LAB164:    if (*((unsigned int *)t4) < *((unsigned int *)t20))
        goto LAB162;

LAB163:    memset(t10, 0, 8);
    t12 = (t21 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t21);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB165;

LAB166:    if (*((unsigned int *)t12) != 0)
        goto LAB167;

LAB168:    t19 = (t10 + 4);
    t22 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t19);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB169;

LAB170:    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t19);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB171;

LAB172:    if (*((unsigned int *)t19) > 0)
        goto LAB173;

LAB174:    if (*((unsigned int *)t10) > 0)
        goto LAB175;

LAB176:    memcpy(t8, t30, 8);

LAB177:    t31 = (t0 + 3336);
    xsi_vlogvar_wait_assign_value(t31, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(86, ng0);
    t2 = (t0 + 4776);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng10)));
    t6 = ((char*)((ng12)));
    memset(t20, 0, 8);
    xsi_vlog_unsigned_divide(t20, 32, t5, 27, t6, 32);
    memset(t21, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB179;

LAB178:    t9 = (t20 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB179;

LAB182:    if (*((unsigned int *)t4) < *((unsigned int *)t20))
        goto LAB180;

LAB181:    memset(t10, 0, 8);
    t12 = (t21 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t21);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB183;

LAB184:    if (*((unsigned int *)t12) != 0)
        goto LAB185;

LAB186:    t19 = (t10 + 4);
    t22 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t19);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB187;

LAB188:    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t19);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB189;

LAB190:    if (*((unsigned int *)t19) > 0)
        goto LAB191;

LAB192:    if (*((unsigned int *)t10) > 0)
        goto LAB193;

LAB194:    memcpy(t8, t30, 8);

LAB195:    t31 = (t0 + 3496);
    xsi_vlogvar_wait_assign_value(t31, t8, 0, 0, 1, 0LL);
    xsi_set_current_line(87, ng0);
    t2 = (t0 + 4936);
    t3 = (t2 + 56U);
    t4 = *((char **)t3);
    t5 = ((char*)((ng11)));
    t6 = ((char*)((ng12)));
    memset(t20, 0, 8);
    xsi_vlog_unsigned_divide(t20, 32, t5, 27, t6, 32);
    memset(t21, 0, 8);
    t7 = (t4 + 4);
    if (*((unsigned int *)t7) != 0)
        goto LAB197;

LAB196:    t9 = (t20 + 4);
    if (*((unsigned int *)t9) != 0)
        goto LAB197;

LAB200:    if (*((unsigned int *)t4) < *((unsigned int *)t20))
        goto LAB198;

LAB199:    memset(t10, 0, 8);
    t12 = (t21 + 4);
    t13 = *((unsigned int *)t12);
    t14 = (~(t13));
    t15 = *((unsigned int *)t21);
    t16 = (t15 & t14);
    t17 = (t16 & 1U);
    if (t17 != 0)
        goto LAB201;

LAB202:    if (*((unsigned int *)t12) != 0)
        goto LAB203;

LAB204:    t19 = (t10 + 4);
    t22 = *((unsigned int *)t10);
    t23 = *((unsigned int *)t19);
    t24 = (t22 || t23);
    if (t24 > 0)
        goto LAB205;

LAB206:    t26 = *((unsigned int *)t10);
    t27 = (~(t26));
    t28 = *((unsigned int *)t19);
    t29 = (t27 || t28);
    if (t29 > 0)
        goto LAB207;

LAB208:    if (*((unsigned int *)t19) > 0)
        goto LAB209;

LAB210:    if (*((unsigned int *)t10) > 0)
        goto LAB211;

LAB212:    memcpy(t8, t30, 8);

LAB213:    t31 = (t0 + 3656);
    xsi_vlogvar_wait_assign_value(t31, t8, 0, 0, 1, 0LL);
    goto LAB2;

LAB7:    t11 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB9;

LAB11:    xsi_set_current_line(64, ng0);
    t18 = ((char*)((ng4)));
    t19 = (t0 + 3816);
    xsi_vlogvar_wait_assign_value(t19, t18, 0, 0, 27, 0LL);
    goto LAB13;

LAB15:    t11 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB17;

LAB19:    xsi_set_current_line(66, ng0);
    t18 = ((char*)((ng4)));
    t19 = (t0 + 3976);
    xsi_vlogvar_wait_assign_value(t19, t18, 0, 0, 27, 0LL);
    goto LAB21;

LAB23:    t11 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB25;

LAB27:    xsi_set_current_line(68, ng0);
    t18 = ((char*)((ng4)));
    t19 = (t0 + 4136);
    xsi_vlogvar_wait_assign_value(t19, t18, 0, 0, 27, 0LL);
    goto LAB29;

LAB31:    t11 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB33;

LAB35:    xsi_set_current_line(70, ng0);
    t18 = ((char*)((ng4)));
    t19 = (t0 + 4296);
    xsi_vlogvar_wait_assign_value(t19, t18, 0, 0, 27, 0LL);
    goto LAB37;

LAB39:    t11 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB41;

LAB43:    xsi_set_current_line(72, ng0);
    t18 = ((char*)((ng4)));
    t19 = (t0 + 4456);
    xsi_vlogvar_wait_assign_value(t19, t18, 0, 0, 27, 0LL);
    goto LAB45;

LAB47:    t11 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB49;

LAB51:    xsi_set_current_line(74, ng0);
    t18 = ((char*)((ng4)));
    t19 = (t0 + 4616);
    xsi_vlogvar_wait_assign_value(t19, t18, 0, 0, 27, 0LL);
    goto LAB53;

LAB55:    t11 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB57;

LAB59:    xsi_set_current_line(76, ng0);
    t18 = ((char*)((ng4)));
    t19 = (t0 + 4776);
    xsi_vlogvar_wait_assign_value(t19, t18, 0, 0, 27, 0LL);
    goto LAB61;

LAB63:    t11 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB65;

LAB67:    xsi_set_current_line(78, ng0);
    t18 = ((char*)((ng4)));
    t19 = (t0 + 4936);
    xsi_vlogvar_wait_assign_value(t19, t18, 0, 0, 27, 0LL);
    goto LAB69;

LAB71:    t11 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB73;

LAB72:    *((unsigned int *)t21) = 1;
    goto LAB73;

LAB75:    *((unsigned int *)t10) = 1;
    goto LAB78;

LAB77:    t18 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB78;

LAB79:    t25 = ((char*)((ng1)));
    goto LAB80;

LAB81:    t30 = ((char*)((ng4)));
    goto LAB82;

LAB83:    xsi_vlog_unsigned_bit_combine(t8, 1, t25, 1, t30, 1);
    goto LAB87;

LAB85:    memcpy(t8, t25, 8);
    goto LAB87;

LAB89:    t11 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB91;

LAB90:    *((unsigned int *)t21) = 1;
    goto LAB91;

LAB93:    *((unsigned int *)t10) = 1;
    goto LAB96;

LAB95:    t18 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB96;

LAB97:    t25 = ((char*)((ng1)));
    goto LAB98;

LAB99:    t30 = ((char*)((ng4)));
    goto LAB100;

LAB101:    xsi_vlog_unsigned_bit_combine(t8, 1, t25, 1, t30, 1);
    goto LAB105;

LAB103:    memcpy(t8, t25, 8);
    goto LAB105;

LAB107:    t11 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB109;

LAB108:    *((unsigned int *)t21) = 1;
    goto LAB109;

LAB111:    *((unsigned int *)t10) = 1;
    goto LAB114;

LAB113:    t18 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB114;

LAB115:    t25 = ((char*)((ng1)));
    goto LAB116;

LAB117:    t30 = ((char*)((ng4)));
    goto LAB118;

LAB119:    xsi_vlog_unsigned_bit_combine(t8, 1, t25, 1, t30, 1);
    goto LAB123;

LAB121:    memcpy(t8, t25, 8);
    goto LAB123;

LAB125:    t11 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB127;

LAB126:    *((unsigned int *)t21) = 1;
    goto LAB127;

LAB129:    *((unsigned int *)t10) = 1;
    goto LAB132;

LAB131:    t18 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB132;

LAB133:    t25 = ((char*)((ng1)));
    goto LAB134;

LAB135:    t30 = ((char*)((ng4)));
    goto LAB136;

LAB137:    xsi_vlog_unsigned_bit_combine(t8, 1, t25, 1, t30, 1);
    goto LAB141;

LAB139:    memcpy(t8, t25, 8);
    goto LAB141;

LAB143:    t11 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB145;

LAB144:    *((unsigned int *)t21) = 1;
    goto LAB145;

LAB147:    *((unsigned int *)t10) = 1;
    goto LAB150;

LAB149:    t18 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB150;

LAB151:    t25 = ((char*)((ng1)));
    goto LAB152;

LAB153:    t30 = ((char*)((ng4)));
    goto LAB154;

LAB155:    xsi_vlog_unsigned_bit_combine(t8, 1, t25, 1, t30, 1);
    goto LAB159;

LAB157:    memcpy(t8, t25, 8);
    goto LAB159;

LAB161:    t11 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB163;

LAB162:    *((unsigned int *)t21) = 1;
    goto LAB163;

LAB165:    *((unsigned int *)t10) = 1;
    goto LAB168;

LAB167:    t18 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB168;

LAB169:    t25 = ((char*)((ng1)));
    goto LAB170;

LAB171:    t30 = ((char*)((ng4)));
    goto LAB172;

LAB173:    xsi_vlog_unsigned_bit_combine(t8, 1, t25, 1, t30, 1);
    goto LAB177;

LAB175:    memcpy(t8, t25, 8);
    goto LAB177;

LAB179:    t11 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB181;

LAB180:    *((unsigned int *)t21) = 1;
    goto LAB181;

LAB183:    *((unsigned int *)t10) = 1;
    goto LAB186;

LAB185:    t18 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB186;

LAB187:    t25 = ((char*)((ng1)));
    goto LAB188;

LAB189:    t30 = ((char*)((ng4)));
    goto LAB190;

LAB191:    xsi_vlog_unsigned_bit_combine(t8, 1, t25, 1, t30, 1);
    goto LAB195;

LAB193:    memcpy(t8, t25, 8);
    goto LAB195;

LAB197:    t11 = (t21 + 4);
    *((unsigned int *)t21) = 1;
    *((unsigned int *)t11) = 1;
    goto LAB199;

LAB198:    *((unsigned int *)t21) = 1;
    goto LAB199;

LAB201:    *((unsigned int *)t10) = 1;
    goto LAB204;

LAB203:    t18 = (t10 + 4);
    *((unsigned int *)t10) = 1;
    *((unsigned int *)t18) = 1;
    goto LAB204;

LAB205:    t25 = ((char*)((ng1)));
    goto LAB206;

LAB207:    t30 = ((char*)((ng4)));
    goto LAB208;

LAB209:    xsi_vlog_unsigned_bit_combine(t8, 1, t25, 1, t30, 1);
    goto LAB213;

LAB211:    memcpy(t8, t25, 8);
    goto LAB213;

}


extern void work_m_00000000000600595060_0379717760_init()
{
	static char *pe[] = {(void *)Always_51_0};
	xsi_register_didat("work_m_00000000000600595060_0379717760", "isim/menu_principal_isim_beh.exe.sim/work/m_00000000000600595060_0379717760.didat");
	xsi_register_executes(pe);
}
